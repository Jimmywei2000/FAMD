library(haven)
CGSS2021=read_sav("C:/Users/MSI-PC/Desktop/656354224290/CGSS2021.sav")

for(i in 6:700){
  if(max(CGSS2021[i],na.rm = TRUE)==88){
    CGSS2021[!is.na(CGSS2021[i]) & CGSS2021[i]==88,i]=NA
  }
  else if(max(CGSS2021[i],na.rm = TRUE)>=95 && max(CGSS2021[i],na.rm = TRUE)<=99){
    CGSS2021[!is.na(CGSS2021[i]) & CGSS2021[i]>=95,i]=NA
  }
  else if(max(CGSS2021[i],na.rm = TRUE)>=995 && max(CGSS2021[i],na.rm = TRUE)<=999){
    CGSS2021[!is.na(CGSS2021[i]) & CGSS2021[i]>=995,i]=NA
  }
  else if(max(CGSS2021[i],na.rm = TRUE)>=9995 && max(CGSS2021[i],na.rm = TRUE)<=9999){
    CGSS2021[!is.na(CGSS2021[i]) & CGSS2021[i]>=9995,i]=NA
  }
  else if(max(CGSS2021[i],na.rm = TRUE)>=99995 && max(CGSS2021[i],na.rm = TRUE)<=99999){
    CGSS2021[!is.na(CGSS2021[i]) & CGSS2021[i]>=99995,i]=NA
  }
  else if(max(CGSS2021[i],na.rm = TRUE)>=999995 && max(CGSS2021[i],na.rm = TRUE)<=999999){
    CGSS2021[!is.na(CGSS2021[i]) & CGSS2021[i]>=999995,i]=NA
  }
}
a=sum(is.na(CGSS2021$A13))
mycol=c("provinces")
for(i in 6:700){
  if(sum(is.na(CGSS2021[i]))<=a+1){
    mycol=append(mycol,colnames(CGSS2021)[i])
  }
}
ACGSS2021=CGSS2021[mycol]

BCGSS2021=na.omit(ACGSS2021)

CCGSS2021 =as.data.frame(lapply(BCGSS2021, as.factor))

NUM=c("A1","A3_1","A8a","A8b","A13","A14","A62","A65","XA1","XB1","XC1")
library(dplyr)
CCGSS2021=CCGSS2021%>%mutate_at(vars(NUM), as.numeric)
CCGSS2021=CCGSS2021[1:139]
library("FactoMineR")
library("factoextra")
myresult <- FAMD(CCGSS2021, ncp = 10, graph = TRUE)

library(psych)

rotated_loadings =varimax(myresult$var$coord)


library(ggcorrplot)

ggcorrplot(rotated_loadings$loadings[21:40, ], type = "lower", lab = TRUE)
ggcorrplot(myresult$var$coord[21:40, ], type = "lower", lab = TRUE)

beforeresult=myresult$var$coord
beforeresult[abs(beforeresult)<0.1]=NA
afterresult=rotated_loadings$loadings
afterresult[abs(afterresult)<0.1]=NA
write.csv(beforeresult, "C:/Users/MSI-PC/Desktop/656354224290/Beforerotate.csv", row.names=TRUE)
write.csv(afterresult, "C:/Users/MSI-PC/Desktop/656354224290/Afterrotate.csv", row.names=TRUE)